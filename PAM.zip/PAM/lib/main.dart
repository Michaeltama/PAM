import 'package:flutter/material.dart';
import 'package:cc/login_page.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kuis PAM',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color.fromARGB(255, 50, 122, 230)),
        useMaterial3: true,
      ),
      home: LoginPage(),
    );
  }
}
