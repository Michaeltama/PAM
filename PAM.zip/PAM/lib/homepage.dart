
// ignore_for_file: unused_import, use_super_parameters

import 'package:flutter/material.dart';
import 'package:cc/page3.dart';
import 'package:cc/login_page.dart';
import 'package:cc/daftar_barang_dummy.dart';

class HomePage extends StatelessWidget {
  final String username;

  const HomePage({Key? key, required this.username}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home Page'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              'Selamat datang, $username!',
              style: TextStyle(fontSize: 16),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const page3()),
              );
            },
            child: const Text( 'Butuh bantuan? Klik untuk pergi ke halaman Panduan dan Dukungan',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
          ),
          Expanded(
            child: GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.8,
                mainAxisSpacing: 7.0,
                crossAxisSpacing: 7.0,
              ),
              itemCount: supermarketItemList.length,
              itemBuilder: (context, index) {
                final SupermarketItem item = supermarketItemList[index];
                return Card(
                  child: Column(
                    children: [
                      Expanded(
                        child: Image.network(
                          item.imageUrls[0],
                          fit: BoxFit.cover,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(7.0),
                        child: Text(item.name),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 7.0),
                        child: Text(item.price),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}